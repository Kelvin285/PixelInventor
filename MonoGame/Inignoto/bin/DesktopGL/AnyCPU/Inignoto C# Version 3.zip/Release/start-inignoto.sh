#! /bin/sh
#starts inignoto on linux
#requires mono to be installed
#mark file this file as execurable"chmod +x" to use if not already done
#should theorticay works on mac maybe since unix-like?
mono Inignoto.exe
